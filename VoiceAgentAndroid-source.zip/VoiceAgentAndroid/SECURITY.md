# Security checklist

- Keep authentication fail-closed: if the biometric prompt is unavailable or cancelled, do not execute commands.
- Require fresh authentication for sensitive operations and expire authenticated sessions after a short, configurable interval.
- Treat speech recognition output as untrusted input. Parse into an allowlisted typed command; never execute arbitrary shell text.
- Do not grant Accessibility Service, Device Admin, notification access, or broad package visibility unless a clearly documented feature requires it.
- Never request SMS/call-log permissions merely to open the dialer or messaging UI.
- Redact secrets, message contents, phone numbers, and personal notes from logs.
- Store OAuth tokens encrypted using Android Keystore-backed keys, and support revocation/clear-data.
- Prefer OAuth Authorization Code with PKCE using a vetted AppAuth/OIDC library. No client secret belongs in an Android app.
- Use HTTPS, certificate validation, narrow scopes, state/nonce validation, redirect URI allowlists, and token expiry handling.
- Add unit, instrumentation, dependency vulnerability, and static analysis checks before release.
