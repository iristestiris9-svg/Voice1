package com.example.voiceagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var authCallback: ((Boolean) -> Unit)? = null

    private val audioPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (!granted) statusUpdate("Microphone permission denied.") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AssistantScreen(
                    onAuthenticate = { callback -> authenticate(callback) },
                    onListen = { callback -> startSpeech(callback) },
                    onCommand = { command -> executeCommand(command) }
                )
            }
        }
    }

    private fun authenticate(callback: (Boolean) -> Unit) {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            callback(false)
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                callback(true)
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                callback(false)
            }
            override fun onAuthenticationFailed() {
                // Prompt remains available for another attempt; no command is authorized.
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Voice Agent")
            .setSubtitle("Authenticate before running a command")
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }

    private fun startSpeech(callback: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
            callback("")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a command")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, SPEECH_REQUEST)
            speechCallback = callback
        } catch (_: Exception) {
            callback("")
        }
    }

    private var speechCallback: ((String) -> Unit)? = null

    @Deprecated("Deprecated by Android; kept for broad device compatibility in this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SPEECH_REQUEST) {
            val text = if (resultCode == RESULT_OK)
                data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            else ""
            speechCallback?.invoke(text)
            speechCallback = null
        }
    }

    private fun executeCommand(raw: String): String {
        val command = raw.trim().lowercase(Locale.getDefault())
        if (command.isBlank()) return "No command received."
        SecurityPolicy.log("command_received", command.take(80))
        return when {
            command.contains("open settings") -> {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                "Opened Android Settings."
            }
            command.contains("open wifi") || command.contains("wifi settings") -> {
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                "Opened Wi-Fi settings."
            }
            command.contains("open bluetooth") || command.contains("bluetooth settings") -> {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                "Opened Bluetooth settings."
            }
            command.contains("open browser") || command.contains("open chrome") -> {
                val launch = packageManager.getLaunchIntentForPackage("com.android.chrome")
                if (launch != null) startActivity(launch) else
                    startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com")))
                "Opened a browser."
            }
            command.contains("volume") -> "For privacy and compatibility, adjust volume with the device buttons."
            command.contains("call ") -> {
                val dial = Intent(Intent.ACTION_DIAL)
                startActivity(dial)
                "Opened the dialer. Review the number and place the call yourself."
            }
            command.contains("send sms") || command.contains("text message") -> {
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
                "Opened messaging. Select the recipient and confirm the message yourself."
            }
            command.contains("note ") -> {
                val note = raw.substringAfter("note ", "").trim()
                NoteStore.append(this, note)
                "Saved a local demo note."
            }
            command.contains("reminder") -> "Reminder agent is a placeholder; scheduling is not implemented yet."
            command.contains("cybersecurity") || command.contains("security scan") ->
                "Cybersecurity agent is a placeholder. Use only authorized systems; no scan was run."
            command.contains("api") || command.contains("oauth") ->
                "API agent is a placeholder. See docs/OAUTH.md for the authorized integration plan."
            else -> "I couldn't map that to a supported local action. Try 'open settings', 'open Wi-Fi settings', or 'note buy groceries'."
        }
    }

    private fun statusUpdate(message: String) { SecurityPolicy.log("status", message) }

    companion object { private const val SPEECH_REQUEST = 9001 }
}

@Composable
private fun AssistantScreen(
    onAuthenticate: ((Boolean) -> Unit) -> Unit,
    onListen: ((String) -> Unit) -> Unit,
    onCommand: (String) -> String
) {
    var authenticated by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Locked. Authenticate to enable commands.") }
    var command by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<String>()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Voice Agent", style = MaterialTheme.typography.headlineMedium)
        Text("Secure multi-agent Android assistant starter")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (authenticated) "Authenticated for this session" else "Authentication required")
                Text(status)
                Button(onClick = {
                    onAuthenticate { ok ->
                        authenticated = ok
                        status = if (ok) "Authentication successful." else "Authentication cancelled or unavailable."
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Authenticate") }
            }
        }
        OutlinedTextField(
            value = command, onValueChange = { command = it },
            label = { Text("Command (or use voice)") }, modifier = Modifier.fillMaxWidth()
        )
        Button(
            enabled = authenticated,
            onClick = {
                status = onCommand(command)
                history = listOf("You: $command", "Agent: $status") + history
                command = ""
            }, modifier = Modifier.fillMaxWidth()
        ) { Text("Run command") }
        OutlinedButton(
            enabled = authenticated,
            onClick = {
                onListen { spoken ->
                    if (spoken.isNotBlank()) {
                        command = spoken
                        status = "Recognized: $spoken. Tap Run command to execute."
                    } else status = "No speech recognized; check microphone permission."
                }
            }, modifier = Modifier.fillMaxWidth()
        ) { Text("Speak command") }
        Text("Recent activity", style = MaterialTheme.typography.titleMedium)
        history.take(10).forEach { Text(it) }
        Text(
            "Sensitive actions open Android system UI and require your confirmation. " +
                "This demo does not run commands silently in the background.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

private object SecurityPolicy {
    fun log(event: String, detail: String) {
        // Starter hook. Production: structured, redacted logs in a private store.
        android.util.Log.i("VoiceAgentSecurity", "$event: ${detail.take(120)}")
    }
}

private object NoteStore {
    fun append(activity: ComponentActivity, note: String) {
        val prefs = activity.getSharedPreferences("demo_notes", android.content.Context.MODE_PRIVATE)
        val previous = prefs.getString("notes", "").orEmpty()
        prefs.edit().putString("notes", (previous + "\n" + note).takeLast(10_000)).apply()
    }
}
